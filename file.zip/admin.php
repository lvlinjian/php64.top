<?php
define("U","admin");
define("P","ftpsxex7939");
?>