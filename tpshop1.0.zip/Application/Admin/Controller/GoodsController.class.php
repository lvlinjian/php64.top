<?php 
namespace Admin\Controller;
use Think\Controller;
class GoodsController extends Controller{
	public function index(){
		// 获取数据库商品信息
		// 实例化模型
		$model =D('Goods');
		$data =$model ->select();
		// 变量赋值
		$this ->assign('data',$data);
		// dump($res);die;
		// 展示商品列表
		$this -> display();
	}
	public function add(){
		// 新增商品
		if (IS_POST){
			// 接收参数
			$data = I('post.');
			// dump($data);
			// 实例化商品模型,传递D参数：对应的数据表名
			$model =D('Goods');
			// 调用图片上传功能，获得图片路径附加到data数组里
			$upload_res =$model ->upload_logo($data);
			// dump($upload_res);
			// dump($model);
			// die;
			// 调用Goods模型的add方法，传递data一维数组
			$res =$model ->add($data);
			if($res){
				// 如果新增成功
				$this ->success('新增成功', U('Admin/Goods/index'));
			}else{
				// 新增失败
				$this ->error('新增失败！');
			}
		}else{
			// 展示add页面
		$this ->display();
		}
	}
	public function edit(){
		if(IS_POST){
			$data =I('post.');
			// dump($data);die;
			// 把修改后的信息保存进数据库
			$model =D('Goods');
			$res =$model ->save($data);
			if($res !==false){
				// 成功
				$this ->success('修改成功！',U('Admin/Goods/index'));
			}else{
				// 失败
				$this ->error('修改失败！');
			}
		}else{
		$id =I('get.id');
		$model =D('Goods');
		$goods =$model -> where(['id' => $id]) -> find();
		// dump($goods);die;
		$this ->assign('goods',$goods);
		$this ->display();
		}
	}
	public function del(){
		// 接收getID
		$id =I('get.id');
		$model =D('Goods');
		$res =$model ->where(['id' => $id]) ->delete();
		// dump($res);die;
		if($res){
			// 删除成功
			$this ->success('删除成功', U('Admin/Goods/index'));
		}else{
			// 如果删除失败！、
			$this ->error('删除失败！');
		}
	}
}