<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
	// 天气预报测试
	public function index(){
		$count=file_get_contents('api_tq_count.txt');
		$this ->assign('count',$count);
		$this ->display();
	}
	public function api_tq(){
		$stime=microtime(true);
		// 和风天气API 
		$url ="https://free-api.heweather.com/s6/weather/now?key=84d56848cbcf440c94c75ed8964e8f9d&location=";
		$url2 =I('get.city');
		// 简单的防注入正则过滤
		$ze='/^[^\'\"^`]+$/i';
		$ze=preg_match($ze,$url2);
		if(!$ze) $url2 = '昌平';
		// dump($url2);die;
		// 创建一个新cURL资源
		$ch = curl_init();
        //设置头信息
        $headers=array( "Accept: application/json", "Content-Type: application/json;charset=utf-8" );
		// 设置URL和相应的选项
		curl_setopt($ch, CURLOPT_URL, $url.$url2);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,$headers);// 不直接输出到浏览器
		// 抓取URL并把它传递给浏览器
		$arr =curl_exec($ch);
		$etime=round(microtime(true)-$stime,3);
		// 统计
		$file = 'api_tq_count.txt';
		$current = file_get_contents($file);
		$current+=1;
		file_put_contents($file, $current);
		// 数据处理
		$a=json_decode($arr,true);
        $b=$a['HeWeather6'][0];
        // print_r($b);die;
        $arr2=array();
        if($b['status']!='ok'){
       		$arr2[]="累计查询次数：".$current."<br>";
		    $arr2[]="本次查询耗时：".$etime." s<br>";
        	$arr2[]='未知城市！';
        }else{
        $arr2[]="本次查询耗时：".$etime." s<br>";
        $arr2[]="累计查询次数：".$current."<br>";
        $arr2[]="国家：".$b["basic"]["cnty"]."<br>";
        $arr2[]="省份：".$b["basic"]["admin_area"]."<br>";
        $arr2[]="城市：".$b["basic"]["location"]."<br>";
        $arr2[]="当前温度：".$b["now"]["tmp"]." ℃"."<br>";
        $arr2[]="体感温度：".$b["now"]["fl"]." ℃"."<br>";
        $arr2[]="相对湿度：".$b["now"]["hum"]."<br>";
        $arr2[]="天气：".$b["now"]["cond_txt"]."<br>";
        $arr2[]="风向：".$b["now"]["wind_dir"]."<br>";
        $arr2[]="风力：".$b["now"]["wind_sc"]." 级<br>";
        $arr2[]="风力：".$b["now"]["wind_spd"]." km/h<br>";
        $arr2[]="大气压强：".$b["now"]["pres"]." hPa<br>";
        $arr2[]="能见度：".$b["now"]["vis"]." km<br>";
        $arr2[]="当地时间：".$b["update"]["loc"]."<br>";
        }
		header("Content-type:text/json;charset=UTF-8");
		$data= json_encode($arr2,JSON_UNESCAPED_UNICODE);
		echo($data);
		// 关闭cURL资源，并且释放系统资源
		curl_close($ch);
	}
}