<?php 
// $xytime =xytime::newtime();// 响应时间开关，注释本行就能禁用
// final class xytime{private $stime;private static $f1;private function __clone(){}private function __construct(){$this->stime=microtime(true);}function __destruct(){echo "time:".round(((microtime(true)-$this->stime)+0.001),3);}public static function newtime($f2=null){if(empty($f2)){if(self::$f1 instanceof self == false){self::$f1 =new self();}}else{self::$f1 =NULL;}return self::$f1;}}
function CURL(){
	// 第一步初始化CURL_INIT;
	$ch =curl_init($url);
	// 第二步设置参数，
	if(IS_POST){
		curl_setopt($ch,CURLOPT_POST,true);
	}
	// 第三步发送请求
	
	// 第四步关闭请求
}