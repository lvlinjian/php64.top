<?php
class tqController extends baseController{
	function index(){
## 检查数据表
		if(!file_exists('table.txt')){
## 能进到这个分支，说明需要创建数据表。
			$m = new tqModel();
			$result = $m->tq_insall();
			if($result===false){
				$zhiling ="创建 数据表....失败！";
				$this->smarty->assign('zhiling',$zhiling);
				$this->smarty->display('_tq_index.html');
				die;
			}else{
				$zhiling ="创建 数据表....成功！";
				$this->smarty->assign('zhiling',$zhiling);
				$this->smarty->display('_tq_index.html');
## 防止重复写入数据表
				file_put_contents('table.txt','如需初始化数据表，请删除我！');
				die;
			}
		}
## 查天气预报(查缓存优先，然后才是实时)
## 判断 是否触发了查询指令
		if(!empty($_POST['citynm'])){
			$stime=round(microtime(true),0);// 即将写入的时间戳
			$etime=round(microtime(true),0);// 当前查询的时间戳
			$url = "http://api.k780.com:88/?app=weather.today&weaid={$_POST['citynm']}&appkey=10003&sign=b59bc3ef6191eb9f747dd4e83c99f2a4&format=xml";
			$m = new tqModel();
			$tianqi = $m->show($_POST['citynm']);
			if($tianqi===false){
				// ------ XML ------------
				$a = file_get_contents($url);// 接收 API 接口返回的数据
				$xml = simplexml_load_string($a);// 转换XML为对象
				// ------ XML end ------------
					if($xml->success == 0){// 不存在的错误城市编号
						$this->smarty->assign('error',$xml);
						$this->smarty->display('_tq_index.html');
						die;
					}
## 展示 API 接口返回的参数
				$zhiling="新建缓存....";
				$this->smarty->assign('zhiling',$zhiling);
				$this->smarty->assign('xml',$xml);
				$this->smarty->display('_tq_show.html');
				$res =$m->add($xml,$stime);// 新建缓存
					if($res===false){
						echo "新建缓存失败！<br>";
					}
					die;
			}
			elseif(($etime - ($tianqi['tq_stime'])) > 3600){// 计算时间差
				// ------ XML ------------
				$a = file_get_contents($url);
				$xml = simplexml_load_string($a);
				// ------ XML end ------------
## 展示 API 接口返回的参数
				$zhiling="更新缓存....";
				$this->smarty->assign('zhiling',$zhiling);
				$this->smarty->assign('xml',$xml);
				$this->smarty->display('_tq_show.html');
				$m->updata($xml,$stime,$_POST['citynm']);die;// 更新缓存
			}
## 展示 本地缓存
			$zhiling="调用本地缓存....";
			$this->smarty->assign('zhiling',$zhiling);
			$this->smarty->assign('tianqi',$tianqi);
			$this->smarty->display('_tq_index.html');
			die;
		}
## 展示 空模板
		$this->smarty->display('_tq_index.html');	
	}


}