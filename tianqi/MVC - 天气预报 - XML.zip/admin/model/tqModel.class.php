<?php
class tqModel extends baseModel{
	protected $arr=array('days','week','cityid','cityno','citynm','temperature','temperature_curr','humidity','weather','weather_curr','weather_icon','wind','winp','temp_high','temp_low','temp_curr');// 写下想要的字段 
	function tq_insall(){
		$sql="DROP TABLE IF EXISTS `tianqi`";
		$this->pdo->exec($sql);//初始化1：删除同名数据表
		## 数据表结构
		$sql="CREATE TABLE `tianqi` (
		  `days` DATE NOT NULL comment '日期',  
		  `week` CHAR(10) COMMENT '星期',
		  `cityId` CHAR(10) NOT NULL COMMENT '城市ID',
		  `cityno` VARCHAR(20) NOT NULL COMMENT '城市拼音',
		  `citynm` VARCHAR(6) NOT NULL COMMENT '城市名称',
		  `temperature` CHAR(10) COMMENT '今日气温',
		  `temperature_curr` CHAR(6) COMMENT '动态气温',
		  `humidity` CHAR(6) COMMENT '湿度',
		  `weather` VARCHAR(6) COMMENT '今日天气',
		  `weather_curr` VARCHAR(6) COMMENT '动态天气',
		  `weather_icon` VARCHAR(45) COMMENT '天气图标',
		  `wind` CHAR(12) COMMENT '风向',
		  `winp` CHAR(5) COMMENT '风力',
		  `temp_high` TINYINT(1) COMMENT '最高温度',
		  `temp_low` TINYINT(1) COMMENT '最低温度',
		  `temp_curr` TINYINT(1) COMMENT '当前温度',
		  `tq_stime` CHAR(10) DEFAULT NULL comment '更新time戳',  
		  PRIMARY KEY (`cityId`),UNIQUE KEY `citynm` (`citynm`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;
		";
		return $this->pdo->exec($sql);// 创建数据表
	}
	
	function show($citynm){
		$sql="SELECT * FROM tianqi WHERE 1=1";
		$sql.=" AND citynm LIKE '%$citynm%'";// 城市名称模糊查询
		return $this->pdo->getOneRow($sql);// 获取缓存数据
	}

	function add($xml,$stime){
		$sql="INSERT INTO `tianqi` SET ";
		foreach ($this->arr as $v) {
		$sql.=" `$v` = '{$xml->result->$v}',";// 遍历数组拼接SQL语句
		}
		$sql.=" `tq_stime` ={$stime}";// 记录下做缓存的时间戳
		return $this->pdo->exec($sql);// 新建缓存
	}

	function updata($xml,$stime,$citynm){
		$sql="UPDATE `tianqi` SET ";
		foreach ($this->arr as $v) {
		$sql.=" `$v` = '{$xml->result->$v}',";// 遍历数组拼接SQL语句
		}
		$sql.=" `tq_stime` ={$stime}";// 当前更新的时间戳
		$sql.=" WHERE `citynm` ='{$citynm}'";// 更新的条件：城市名称相等
		return $this->pdo->exec($sql);// 更新缓存
	}
}