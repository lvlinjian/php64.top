<?php

/**
 * @Author: jsy135135
 * @email:732677288@qq.com
 * @Date:   2018-03-08 14:50:45
 * @Last Modified by:   jsy135135
 * @Last Modified time: 2018-03-08 15:01:20
 * @Note: 配置文件
 */
define("TOKEN", "miniblog");
define("APPID", "wx3e4fcc74dffe202c");
define("APPSECRET", "e9d77d6481ef66760ffea1030b95ee31");