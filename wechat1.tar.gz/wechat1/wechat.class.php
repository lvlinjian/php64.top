<?php
/**
 * @Author: jsy135135
 * @email:  732677288@qq.com
 * @Date:   2018-03-08 14:50:37
 * @Last Modified by:   TabKey9
 * @Last Modified time: 2018-04-02 21:10:15
 */
// 引入配置文件
require './wechat.cfg.php';

class Wechat
{

    // 封装类成员
    // private  私有
    // public  公共
    // protected  受保护
    // 构造方法
    public function __construct()
    {
        //实列时会触发，进行相关参数的初始化操作
        $this->token = TOKEN;
        $this->appid = APPID;
        $this->appsecret = APPSECRET;
        // 模板
        // ToUserName 接收方帐号
        // FromUserName 开发者微信号
        // CreateTime 消息创建时间 （整型）
        // MsgType text
        // Content 回复的消息内容
        $this->textTpl = "<xml>
        <ToUserName><![CDATA[%s]]></ToUserName>
        <FromUserName><![CDATA[%s]]></FromUserName>
        <CreateTime>%s</CreateTime>
        <MsgType><![CDATA[%s]]></MsgType>
        <Content><![CDATA[%s]]></Content>
        <FuncFlag>0</FuncFlag>
        </xml>";
    }
    // 类相关方法实现
    // :调用校验方法
    public function valid()
    {
        $echoStr = $_GET["echostr"];
        //valid signature , option
        if ($this->checkSignature()) {
            echo $echoStr;
            exit;
        }
    }
    // 检查签名
    private function checkSignature()
    {
        $signature = $_GET["signature"];
        $timestamp = $_GET["timestamp"];
        $nonce = $_GET["nonce"];
        $token = $this->token;
        $tmpArr = array($token, $timestamp, $nonce);
        // use SORT_STRING rule
        sort($tmpArr, SORT_STRING);
        $tmpStr = implode($tmpArr);
        $tmpStr = sha1($tmpStr);
        if ($tmpStr == $signature) {
            return true;
        } else {
            return false;
        }
    }
    // 封装请求方法
    // curl四步
    // 支持http、https协议，支持get和post请求方式
    public function request($url,$https=true,$method='get',$data=null)
    {
        // 1、初始化
        $ch = curl_init($url);
        // 2、配置
        // 返回数据以文件流形式
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        // 模拟为浏览器发送
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3218.0 Safari/537.36');
        // 支持https
        if($https === true)
        {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        }
        // 支持post
        if($method === 'post')
        {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        }
        // 3、发送请求
        $content = curl_exec($ch);
        // 4、关闭资源
        curl_close($ch);
        // 返回数据
        return $content;
    }
    // 获取access_token
    public function getAccessToken()
    {
        // 判断换成是否有效
        $redis = new Redis();
        $redis->connect('127.0.0.1',6379);
        $access_token = $redis->get('access_token');
        // 没有或者过期，返回false
        if($access_token === false){
            // 1、url
            $url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$this->appid.'&secret='.$this->appsecret;
            // 2、请求方式
            // 3、发送请求
            $content = $this->request($url);
            // 4、处理返回值
            $access_token = json_decode($content)->access_token;
            // 缓存数据
            $redis->set('access_token',$access_token);
            $redis->setTimeout('access_token',7000);
        }
        // echo $access_token;
        return $access_token;
    }
    // 消息管理
    public function responseMsg()
    {
        //get post data, May be due to the different environments
        $postStr = $GLOBALS["HTTP_RAW_POST_DATA"];
        // file_put_contents('./debug.txt', $postStr);
        //extract post data
        if (!empty($postStr)) {
            /* libxml_disable_entity_loader is to prevent XML eXternal Entity Injection,
              the best way is to check the validity of xml by yourself */
            libxml_disable_entity_loader(true);
            $postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
            // 通过接收不同的数据类型，进行不同的方法处理
            switch ($postObj->MsgType) {
                // 调用文本处理方法
                case 'text':
                    $this->doText($postObj);
                    break;
                // 调用事件处理方法
                case 'event':
                    $this->doEvent($postObj);
                    break;
                default:
                    break;
            }
        }
    }
    // 文本消息处理
    private function doText($postObj)
    {
        // file_put_contents('yuyin.txt',$postObj->Content);
        $keyword = trim($postObj->Content);
        if (!empty($keyword)) {
            // 通过用户传输的不同的文本值，进行不同的回复
            $contentStr = "Welcome to wechat world!";
            if (stripos($keyword, '帮助') !== false || stripos($keyword, 'help') !== false) {
                $contentStr = "【API_长链接转短链接_使用说明】\n回复示例1：\nhttp://m.baidu.com\n回复示例2：\nhttps://m.baidu.com";
            }elseif(stripos($keyword, 'http') !== false){
                // 调用“长链接转换短链接”方法
                $content = $this->long2short($keyword);
                $contentStr = '原链接：'.$content['long_url']."\n转微信短链接：\n".$content['short_url'];
            }else{
                // 接入自动回复机器人
                $content = file_get_contents('http://api.qingyunke.com/api.php?key=free&appid=0&msg='.$keyword);
                // 转json取数据
                $contentStr = json_decode($content)->content;
                // 替换换行
                $contentStr = str_replace('{br}', "\n", $contentStr);
            }
            // 替换模板变量，然后echo
            $resultStr = sprintf($this->textTpl, $postObj->FromUserName, $postObj->ToUserName, time(), 'text', $contentStr);
            echo $resultStr;
        }
    }
    // 事件消息处理
    public function doEvent($postObj)
    {
        // 不同的事件交由不同的方法处理
        switch ($postObj->Event) {
            case 'subscribe':
                // 关注事件
                $this->doSubscribe($postObj);
                break;
            case 'unsubscribe':
                // 取消关注事件
                $this->doUnsubscribe($postObj);
                break;
            case 'click':
                // 自定义菜单点击事件
                $this->doClick($postObj);
                break;
            default:
        }
    }
    // 关注事件
    public function doSubscribe($postObj)
    {
        // 拼接问候语
        $contentStr = "欢迎您关注微信测试号！\n\n发送‘help’或者‘帮助’获取帮助！";
        $resultStr = sprintf($this->textTpl,$postObj->FromUserName,$postObj->ToUserName,time(),'text',$contentStr);
        // file_put_contents('./test1.txt',$resultStr);
        echo $resultStr;
    }
    // 取消关注事件
    public function doUnsubscribe($postObj)
    {
        // 记录用户离开的时间和具体人
        // file_put_contents('./leave.txt',$postObj->FromUserName);
        $redis = new Redis();
        $redis->connect('127.0.0.1',6379);
        $data = array(
            'time' => $postObj->CreateTime,
            'opendID' => $postObj->FromUserName
        );
        // hash存储
        $redis->hMset($postObj->FromUserName,$data);
    }
    // 创建菜单
    public function createMenu()
    {
        // 1、url
        $url = 'https://api.weixin.qq.com/cgi-bin/menu/create?access_token='.$this->getAccessToken();
        // 2、请求方式
        $data = '{
                 "button":[
                 {
                      "type":"click",
                      "name":"示例",
                      "key":"test"
                  },
                  {
                       "type":"view",
                       "name":"TabKey9 博客",
                       "url":"https://miniblog.top"
                  },
                  {
                       "name":"更多",
                       "sub_button":[
                       {
                           "type":"view",
                           "name":"百度搜索",
                           "url":"https://www.baidu.com"
                        },
                        {
                            "type":"view",
                            "name":"虎绿林论坛",
                            "url":"https://hu60.net"
                         }]
                   }]
                }';
        // 3、发送请求
        $content = $this->request($url,true,'post',$data);
        // 4、处理返回值
        $content = json_decode($content);
        if($content->errcode == 0){
            echo '提示信息：菜单创建成功！';
        }else{
            echo '提示信息：菜单创建失败!'.'<br />';
            echo '错误码:'.$content->errcode.'<br />';
            echo '错误信息:'.$content->errmsg;
        }
    }
    // 查询菜单
    public function showMenu()
    {
        // 1、url
        $url = 'https://api.weixin.qq.com/cgi-bin/menu/get?access_token='.$this->getAccessToken();
        // 2、请求方式
        // 3、发送请求
        $content = $this->request($url);
        // 4、处理返回值
        if (stripos($content, 'errcode')) {
          // 菜单不存在
          echo '提示信息：菜单不存在!';
        }elseif (stripos($content, 'menu')) {
          echo '提示信息：菜单已存在<br><pre>';
          print_r($content);
          echo '</pre>';
        }
    }
    // 删除菜单
    public function delMenu()
    {
        // 1、url
        $url = 'https://api.weixin.qq.com/cgi-bin/menu/delete?access_token='.$this->getAccessToken();
        // 2、请求方式
        // 3、发送请求
        $content = $this->request($url);
        // 4、处理返回值
        $content = json_decode($content);
        if($content->errcode == 0){
            echo '提示信息：菜单删除成功！';
            // echo '提示信息：菜单删除成功！';
        }else{
            echo '提示信息：菜单删除失败!'.'<br />';
            echo '错误码:'.$content->errcode.'<br />';
            echo '错误信息:'.$content->errmsg;
        }
    }
    // 自定义菜单点击事件处理方法
    public function doClick($postObj)
    {
        // 不同的值不同处理方法
        if ($postObj->EventKey == 'test') {
          // 长链接转换短链接-示例1
          $content = $this->long2short('https://m.baidu.com');
          $contentStr = '原链接：'.$content['long_url']."\n转微信短链接：\n".$content['short_url'];
          // 替换模板变量，然后echo
          $resultStr = sprintf($this->textTpl, $postObj->FromUserName, $postObj->ToUserName, time(), 'text', $contentStr);
          echo $resultStr;
        }
    }
    // 微信API-长链接转短链接_By：TabKey9
    public function long2short($keyword)
    {
        // file_put_contents('./debug.txt', $postObj->FromUserName);exit();
        // 如果必需参数为空，则不继续执行,过滤非http开头的网址
        if(empty($keyword) || stripos($keyword,"http") === false){exit();}
        // 获取最新密钥
        $access_token = $this->getAccessToken();
        $data='{"action":"long2short","long_url":"'.$keyword.'"}';
        //长链接转短链接接口地址
        $shorturl='https://api.weixin.qq.com/cgi-bin/shorturl?access_token='.$access_token;
        // 调用请求函数，发送xml数据
        $res = $this->request($shorturl,'','post',$data);
        $shortarr=(array)json_decode($res);
        if ($shortarr['errcode'] !== 0) {
            $shortarr = array('long_url' => $keyword, 'short_url' => '未知错误，请截图并联系管理员！');
        }else{
            $shortarr['long_url'] = $keyword;            
        }
        return $shortarr;
    }
}