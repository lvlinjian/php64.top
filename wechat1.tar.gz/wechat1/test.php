<?php
header("content-type:text/html;charset=UTF-8");
/**
 * @Author: TabKey9
 * @email:  admin@tlip.cn
 * @Date:   2018-04-03 6:50:37
 * @Last Modified by:   TabKey9
 * @Last Modified time: 2018-04-03 11:51:15
 */
require './wechat.class.php';
$wechat = new Wechat();
echo '<h2>微信测试号 - 调试页面</h2>';

// 获取最新的 AccessToken
echo '获取最新的 AccessToken 示例：http://yourIP/wechat1/test.php?token=1<br>token=任意值';
if ($_GET["token"]) {
	$mytoken = $wechat->getAccessToken();
	echo "<br><br>",$mytoken;
}


echo '<hr>【菜单】调试示例：http://yourIP/wechat1/test.php?menu=1<br>menu=1  ->  创建菜单<br>menu=2  ->  删除菜单<br>menu=3  ->  查看菜单<br><br>';
switch ($_GET["menu"]) {
	case '1':
		// 创建菜单
		$wechat->createMenu();
		break;
	case '2':
		// 删除菜单
		$wechat->delMenu();
		break;
	case '3':
		// 查询菜单
		$wechat->showMenu();
		break;
}

echo '<hr>【长链接转微信短链接】调试示例：http://yourIP/weixin/test.php?url=https://m.baidu.com <br>url=http://m.baidu.com  ->  示例1<br>url=https://m.baidu.com  ->  示例2<br><br>';
if ($_GET["url"]) {
	echo json_encode($wechat->long2short($_GET["url"]));
}